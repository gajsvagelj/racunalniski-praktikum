#Sestavi izraz, katerega vrednost je vsota števk trimestnega celega števila n



stevilo = int(input('Vneci trimestno celo število '))

abs_stevilo = abs(stevilo)#zapišemo absolutno vrednost števila, saj v nasprotnem primeru
#pride do težave pri celoštevilskem deljenju
#dobimo enice, desetice in stotice

enice = abs_stevilo % 10
desetice = abs_stevilo // 10 % 10
stotice = abs_stevilo // 100
vsota = enice + desetice + stotice
#jih seštejemo

print(f'Vsota števk trimestnega celega števila {stevilo} je {vsota}.')
